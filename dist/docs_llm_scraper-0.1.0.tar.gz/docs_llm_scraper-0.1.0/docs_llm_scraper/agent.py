"""
Agent module for integrating with Llama Stack.

Provides a RAG-enabled chatbot agent using Llama Stack as a library.
"""
import os
import json
import logging
from typing import Dict, List, Optional
from pathlib import Path
import tempfile
import shutil
import importlib.util
import dotenv

# Check if llama-stack and llama-stack-client are installed
try:
    from llama_stack.distribution.library_client import LlamaStackAsLibraryClient
    from llama_stack_client import Agent
except ImportError:
    raise ImportError(
        "Required packages are not installed. Install them with 'pip install llama-stack llama-stack-client'"
    )

logger = logging.getLogger(__name__)

class LlamaAgent:
    """
    LlamaAgent class for creating and managing a Llama Stack agent.
    
    Uses Llama Stack as a library to create an agent with the docs-llm-pkg
    content as a knowledge source.
    """
    
    def __init__(
        self, 
        docs_pkg_path: str,
        model_id: str = "meta-llama/Llama-3-8B-Instruct",
        provider_id: str = "fireworks",
        load_env: bool = True
    ):
        """
        Initialize the LlamaAgent.
        
        Args:
            docs_pkg_path: Path to docs-llm-pkg directory
            model_id: LLM model ID to use
            provider_id: Provider ID (e.g., 'ollama', 'fireworks', 'openai')
            load_env: Whether to load .env file for API keys
        """
        if load_env:
            dotenv.load_dotenv()
            
        # Set up paths
        self.docs_pkg_path = Path(docs_pkg_path)
        if not self.docs_pkg_path.exists():
            raise ValueError(f"Docs package path does not exist: {docs_pkg_path}")
            
        # Load manifest to get site name
        manifest_path = self.docs_pkg_path / "manifest.json"
        if manifest_path.exists():
            with open(manifest_path, 'r', encoding='utf-8') as f:
                manifest = json.load(f)
                self.site_name = manifest.get('site', 'Documentation')
        else:
            logger.warning("No manifest.json found, using default site name")
            self.site_name = "Documentation"
            
        # Set config
        self.model_id = model_id
        self.provider_id = provider_id
        
        # Initialize client as library
        self._setup_client()
        
    def _setup_client(self) -> None:
        """
        Set up the Llama Stack client as a library.
        """
        # Prepare provider-specific data
        provider_data = {}
        
        # Add API keys to provider data based on provider
        if self.provider_id == "fireworks":
            api_key = os.environ.get('FIREWORKS_API_KEY')
            if not api_key or api_key == "sk-xxxx":
                raise ValueError("Please set a valid FIREWORKS_API_KEY in your .env file")
            provider_data["api_key"] = api_key
        elif self.provider_id == "openai":
            api_key = os.environ.get('OPENAI_API_KEY')
            if not api_key or api_key == "sk-xxxx":
                raise ValueError("Please set a valid OPENAI_API_KEY in your .env file")
            provider_data["api_key"] = api_key
        
        logger.info(f"Initializing Llama Stack as library with provider: {self.provider_id}")
        
        # Initialize the library client
        self.client = LlamaStackAsLibraryClient(
            self.provider_id,
            provider_data=provider_data
        )
        self.client.initialize()
        
        # Set up vector store (auto-created in memory if not specified)
        self.vector_store = self._setup_vector_store()
        
    def _setup_vector_store(self) -> str:
        """
        Set up vector store for document chunks.
        
        Returns:
            str: Vector store ID
        """
        # For simplicity, we'll use an in-memory vector store called docs_assistant
        vector_store_id = "docs_assistant"
        logger.info(f"Using in-memory vector store: {vector_store_id}")
        return vector_store_id
    
    def ingest_chunks(self) -> None:
        """
        Ingest documentation chunks into the vector database.
        """
        chunks_dir = self.docs_pkg_path / "chunks"
        if not chunks_dir.exists():
            raise ValueError(f"Chunks directory does not exist: {chunks_dir}")
            
        chunks = []
        for fp in chunks_dir.glob("*.json"):
            if fp.name == "index.json":
                continue  # Skip index file
                
            with open(fp, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            # Ensure required fields
            data.setdefault("mime_type", "text/markdown")
            data.setdefault("metadata", {})["slug"] = fp.stem
            chunks.append(data)
            
        if not chunks:
            logger.warning("No chunks found to ingest")
            return
            
        logger.info(f"Ingesting {len(chunks)} chunks into vector store")
        try:
            self.client.vector_io.insert(vector_db_id=self.vector_store, chunks=chunks)
            logger.info(f"Successfully ingested {len(chunks)} chunks")
        except Exception as e:
            logger.error(f"Error ingesting chunks: {str(e)}")
            raise
        
    def create_agent(self, instructions: Optional[str] = None) -> Agent:
        """
        Create a new Llama Stack agent.
        
        Args:
            instructions: Custom instructions for the agent
            
        Returns:
            Agent: Configured Llama Stack agent
        """
        if instructions is None:
            instructions = (
                f"You are a helpful documentation assistant for {self.site_name}. "
                f"Use the knowledge_search tool to find information from the {self.site_name} documentation. "
                f"Always cite your sources with the document slug or ID when answering questions. "
                f"If you don't know the answer, say so instead of making up information."
            )
            
        agent = Agent(
            client=self.client,
            model=self.model_id,
            instructions=instructions,
            tools=[
                {
                    "name": "builtin::rag/knowledge_search",
                    "args": {"vector_db_ids": [self.vector_store]},
                }
            ],
        )
        
        return agent
        
    def create_session(self, agent: Agent, session_id: str = "docs_assistant") -> str:
        """
        Create a new agent session.
        
        Args:
            agent: Configured agent
            session_id: Session ID
            
        Returns:
            str: Session ID
        """
        return agent.create_session(session_id)
        
    def chat(self, agent: Agent, session_id: str, query: str) -> str:
        """
        Send a query to the agent and get a response.
        
        Args:
            agent: Configured agent
            session_id: Session ID
            query: User query
            
        Returns:
            str: Agent response
        """
        resp = agent.create_turn([
            {"role": "user", "content": query}
        ], session_id=session_id)
        
        return resp.output_message.content